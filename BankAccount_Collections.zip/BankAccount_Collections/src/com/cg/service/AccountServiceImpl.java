package com.cg.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.dao.AccountDao;
import com.cg.dao.AccountDaoImpl;
import com.cg.exceptions.AccountNotFoundException;
import com.cg.exceptions.IncorrectDetailsException;
import com.cg.exceptions.InsuffecientBalanceException;
import com.cg.exceptions.InvalidMailException;
import com.cg.exceptions.InvalidPhoneNumberException;


public class AccountServiceImpl  implements AccountService{
	AccountDao dao=new AccountDaoImpl();
	@Override
	public String createAccountDao(Account user) throws  IncorrectDetailsException, InvalidMailException, InvalidPhoneNumberException{
		// TODO Auto-generated method stub
		String AccountNumber=null;
		try 
		{
			Random rand=new Random();
			int num=rand.nextInt(9000000)+1000000;
			 AccountNumber=String.valueOf(num);
			dao.createAccountDao(AccountNumber, user);
		}
		catch(Exception e)
		{
			throw e;
		}
		return AccountNumber;
		
	}


	@Override
	public Account viewAccount(String AccountNumber) throws AccountNotFoundException{

		try
		{
			return dao.viewAccount(AccountNumber);
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	@Override
	public void addMoney(String AccountNumber, int Amount) throws AccountNotFoundException {
		// TODO Auto-generated method stub
		try
		{
			dao.addMoney(AccountNumber, Amount);
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	@Override
	public void transfer(String AccountNumber1, String AccountNumber2, int Amount) throws InsuffecientBalanceException,AccountNotFoundException {
		// TODO Auto-generated method stub
		try {
			dao.transfer(AccountNumber1, AccountNumber2, Amount);
			}
		catch(Exception e)
		{
			throw e;
		}
		
	}


	@Override
	public HashMap<String, Account> getAllAccounts() {
		// TODO Auto-generated method stub
		try {
			return dao.getAllAccounts();
		}
		catch(Exception e)
		{
			throw e;
		}
	}


	@Override
	public void showTransaction(String accountNo) throws AccountNotFoundException {
		if (dao.userList.containsKey(accountNo)) {
			List<Transaction> trans = dao.userList.get(accountNo).getTrans();
			Collections.sort(trans);
			DateFormat simple = new SimpleDateFormat("dd/MM/yyyy  HH:mm");
			System.out.println("Transaction Id    \tDate    \tType    \tAmount    \t Description");
			for (Transaction transaction : trans) {
				String date = simple.format(new Date((long) transaction.getTimeInMiliSeconds()));
				System.out.println(transaction.getTransId() + "   \t" + date + "   \t" + transaction.getTransAmount()
						+ "    s\t" + transaction.getTransDescription());
			}

		} else
			throw new AccountNotFoundException(e);
	}
	}

}
