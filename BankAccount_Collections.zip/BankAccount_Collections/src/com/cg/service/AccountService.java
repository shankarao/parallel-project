package com.cg.service;

import java.util.HashMap;

import com.cg.bean.Account;
import com.cg.exceptions.AccountNotFoundException;
import com.cg.exceptions.IncorrectDetailsException;
import com.cg.exceptions.InsuffecientBalanceException;
import com.cg.exceptions.InvalidMailException;
import com.cg.exceptions.InvalidPhoneNumberException;



public interface AccountService {
	public String createAccountDao(Account user) throws IncorrectDetailsException, InvalidMailException, InvalidPhoneNumberException;
	public Account viewAccount(String AccountNumber) throws AccountNotFoundException;
	public void addMoney(String AccountNumber, int Amount) throws AccountNotFoundException;
	public void transfer(String AccountNumber1,String AccountNumber2, int Amount) throws InsuffecientBalanceException, AccountNotFoundException;
	public void showTransaction(String accountNo) throws AccountNotFoundException;
	public HashMap<String, Account> getAllAccounts();
}
