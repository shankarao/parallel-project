package com.cg.exceptions;

public class AccountNotFoundException extends Exception{
	public AccountNotFoundException()
	{
		super("The Account Number is not found");
	}

}
