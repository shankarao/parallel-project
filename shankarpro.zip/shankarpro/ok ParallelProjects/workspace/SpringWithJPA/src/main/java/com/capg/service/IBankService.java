package com.capg.service;

import java.util.List;

import com.capg.entity.TransactionEntity;

public interface IBankService {
     public boolean createAccount(String name,String phoneNo, String password, long accountNo,int balance) ;
     public int showBalance(long accountNo) ;
     public int depositAmount(long accountNo, int deposit) ;
     public int withdrawAmount(long accountNo, int withdraw) ;
     public boolean fundTransfer(long accountNo , long accno,int amount) ;
     public boolean validateAccount(long accountNo,String password) ;
 	 public List<TransactionEntity> getTransaction(long accountNo)  ;
	public int passwordValidate(String password);
	public int checkBalance(int balance);
	int mobNoValidate(String phoneNo);
	int nameValidate(String name);

}
	