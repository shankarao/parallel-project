package com.cg.restful.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.restful.dao.BankDAO;
import com.cg.restful.dao.TransactionDao;
import com.cg.restful.entity.Customer;
import com.cg.restful.entity.Transaction;

@Service
public class BankService {
	@Autowired
	BankDAO dao;
	@Autowired
	TransactionDao transactionDao;

	public List<Customer> CreateAccount(Customer customer) {
		dao.save(customer);
		return dao.findAll();
	}

	public float ShowBalance(Long accno) {

		return dao.findById(accno).get().getBalance();
	}

	public Optional<Customer> Deposit(long accn, double amount) {
		Customer c = dao.findById(accn).get();
		Transaction transaction = new Transaction();
		float initialBalance = c.getBalance();
		float finalBalance = (float) (initialBalance + amount);
		c.setBalance(finalBalance);
		transaction.setTransactionType("Deposit");
		transaction.setAccountNumber(accn);
		transaction.setAmount(amount);
		transactionDao.save(transaction);
		dao.save(c);
		return dao.findById(accn);
	}

	public Optional<Customer> WithDraw(long accno, double amount) {
		Customer c = dao.findById(accno).get();
		Transaction transaction = new Transaction();
		float initialBalance = c.getBalance();
		float finalBalance = (float) (initialBalance - amount);
		c.setBalance(finalBalance);
		transaction.setAccountNumber(accno);
		transaction.setAmount(amount);
		transaction.setTransactionType("Withdraw");
		transactionDao.save(transaction);
		dao.save(c);
		return dao.findById(accno);
	}

	public List<Customer> TransferFund(long sourceaccno, long destinationaccno, double amount) {
		Customer sourceCust = dao.findById(sourceaccno).get();
		Transaction transaction=new Transaction();
		Transaction destitransaction=new Transaction();
		Customer destiCust = dao.findById(destinationaccno).get();
		float sourceInitialbal = sourceCust.getBalance();
		float destiInitialbal = destiCust.getBalance();
		float sourceFinalBal = (float) (sourceInitialbal - amount);
		float destiFinalBal = (float) (destiInitialbal + amount);
		sourceCust.setBalance(sourceFinalBal);
		destiCust.setBalance(destiFinalBal);
		transaction.setAccountNumber(sourceaccno);
		transaction.setAmount(amount);
		transaction.setTransactionType("Transfer");
		transactionDao.save(transaction);
		destitransaction.setAccountNumber(destinationaccno);
		destitransaction.setTransactionType("transfer");
		destitransaction.setAmount(amount);
		transactionDao.save(destitransaction);
		return dao.findAll();

	}

	public List<Transaction> PrintTransaction(long accno) {
		transactionDao.findById(accno);
		return transactionDao.findAll();
	}

}
