package com.cg.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BankDaoImplTest {

	@Test
	void test() 
	{
		
	}

}
