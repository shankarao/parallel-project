package com.capg.dao;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class bankDaoTest {
	bankDaoImpl bd = new bankDaoImpl();
	
	@Test
	public void Search()
	{
		assertTrue("This will succeed.", true);
		//assertTrue("This will fail!", false);
	}

}
