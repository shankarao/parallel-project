package com.capg.main;
import java.util.Scanner;

import com.capg.entity.bankEntity;
import com.capg.entity.transactionEntity;
import com.capg.service.BankService;
public class main {
	public static void Menu()
	{
		System.out.println("\n\n<<<<<<<<<<<<<<<<<<<<.............Welcome to MAY Bank Application.............>>>>>>>>>>>>>>>>>>");
		
		System.out.println("\n\nChoose your option: \n 1. Create Account\n2. Show Balance\n3. Deposit amount\n 4. WithDraw amount\n5. Fund Transfer\n6. Print Transaction\n7. Exit");
		
		System.out.println("Enter Your choice : ");
	}
	public static void main(String[] args) throws InvalidException {
		do{
			Menu();
		
		 Scanner scan=new Scanner(System.in);
		 BankService service=new BankService();
		 bankEntity bank=new bankEntity();
		 transactionEntity trans=new transactionEntity();
		 transactionEntity trans1=new transactionEntity();
	 int opt=scan.nextInt();
		 
	 switch(opt)
	 {
	 case 1:
		 System.out.println("Enter the reqiured details to create Account\n");
		 System.out.println("Enter the Account Name");
		 String name=scan.next();
		 if(name==null||name.length()>12)
		 {
			 throw new InvalidException("Please Enter the valid Name ");
		 }
		 System.out.println("Enter the Contact Number");
		 String mobileno=scan.next();
		 if(mobileno.length()!=10)
		 {
			 throw new InvalidException("Please Enter the valid Contact Number");
		 }
		 
		 bank.setAccId();
		 bank.setAccountantName(name);
		 bank.setMobileno(mobileno);
		 bank.setAccBalance(1500);
		 
		 
		 service.CreateAccount(bank);		
		 
		 System.out.println("Your account has been created Successfully !!!");
		 int id=bank.getAccId();
		 service.getAccountById(id);
		 System.out.println("Your Account Number is :"+bank.getAccId());
	
	  break;
	 case 2:
		 System.out.println("Enter your account number for Balance enquiry");
		 int accid=scan.nextInt();
		 if(accid==0)
		 {
			 throw new InvalidException("Please enter valid Account number");
		 }
		 bank=service.getAccountById(accid);
		 System.out.println("Account holder Name: "+bank.getAccountantName());
		 System.out.println(" Your Account Balance is: "+bank.getAccBalance());
	
		 break;
		 
	 case 3:
		
		 System.out.println("Enter your Account number");
		 int depId=scan.nextInt();
		 if(depId==0)
		 {
			 throw new InvalidException("Please Enter valid Account number");
		 }
		 bank=service.getAccountById(depId);	
		 System.out.println("Account holder Name: "+bank.getAccountantName());
		 System.out.println(" Your Account Balance is: "+bank.getAccBalance());
		 int initbal=bank.getAccBalance();
		 System.out.println("Enter the amount you want to Deposit");
		 int depAmt=scan.nextInt();
		 int finalbal=initbal+depAmt;
		 bank.setAccBalance(finalbal);
		 service.Deposit(bank);

		 //Updating In Transaction Table
		 
		 trans.setTransactionType("Deposit");
		 trans.setAccId(depId);
		 trans.setAmount(depAmt);
		 service.addTransaction(trans);
		 bank.setT(trans);
		 
		 
		 bank=service.getAccountById(depId);
		 System.out.println("Hello  "+bank.getAccountantName());
		 System.out.println("Your account balance after depositing "+depAmt+" Rs is "+bank.getAccBalance());
		
		 break;
	 case 4:
		
		 System.out.println("Enter your account number");
		 int wid=scan.nextInt();
		 if(wid==0)
		 {
			 throw new InvalidException("Please enter valid Account number");
		 }
		 bank=service.getAccountById(wid);						
		 System.out.println("Hello... "+bank.getAccountantName());
		 System.out.println(" Your Account Balance is: "+bank.getAccBalance());
		 int intbal=bank.getAccBalance();							//initial balance
		
		 System.out.println("\n Enter the Amount you want to Withdraw");
		 int wamt=scan.nextInt();
		 int finalBal=intbal-wamt;
		 bank.setAccBalance(finalBal);
 		 service.Withdraw(bank);
 		 
 		 
		 //Updating In Transaction Table
		 trans.setTransactionType("Withdraw");
		 trans.setAccId(wid);
		 trans.setAmount(wamt);
		 service.addTransaction(trans);
		 bank.setT(trans);
		 
		 bank=service.getAccountById(wid);
		 System.out.println("Hello ..... "+bank.getAccountantName());
		 System.out.println("Your Remaining Account Balance after Withdraw "+wamt+" Rs is"+bank.getAccBalance());
		
		 break;
	 case 5:
	
		 System.out.println("Enter the senders account number");
		 int fid=scan.nextInt();	//From Account Id (Sender)
		 if(fid==0)
		 {
			 throw new InvalidException("Please enter valid Account number");
		 }
		 bank=service.getAccountById(fid);
		 int bal=bank.getAccBalance();						//Initial Balance
		 System.out.println("Enter the amount you want to transfer");
		 int fund=scan.nextInt();	//Amount to be transfered
		 System.out.println("Enter the Recievers Account number");
		 
		 int tid=scan.nextInt();
		 if(tid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 
		//Removing the Balance transfered from sender Account 
		 bank=service.getAccountById(fid);
		 int bal1=bal-fund;
		 bank.setAccBalance(bal1);
		 service.Deposit(bank);
		 
		 //updating the Balance recieved from Sender
		 bank=service.getAccountById(tid);
		 int tbal=bank.getAccBalance();
		 int tbalance=tbal+fund;
		 bank.setAccBalance(tbalance);
		 service.Deposit(bank);
		
		 
		 //updating In transaction Table
		 trans.setTransactionType("Transfered to "+tid);
		 trans.setAccId(fid);
		 trans.setAmount(fund);
		 service.addTransaction(trans);
		 bank.setT(trans);
		 int a= trans.getTransactionId();
		 
		
		 bank=service.getAccountById(fid);
		 System.out.println("helooo...."+bank.getAccountantName());
		 System.out.println("The remaining balance in your account is "+bank.getAccBalance());
		
		 break;
		 
	 case 6:
	
		System.out.println("Enter the account number");
		int trid=scan.nextInt();
		//trans.setAccId(trid);
		service.PrintTransactions(trid);
	
		 break;
	 case 7:
		 System.out.println("<<<<<<<<<<<<<<<<<<<<.............Thank you for using our Bank Services.............>>>>>>>>>>>>>>>>>>");
		 System.exit(0);
	 }
	}while(true);
}
}