package com.capg.service;

import com.capg.entity.bankEntity;

public interface BankServiceInterface {
	public   bankEntity getAccountById(int id);

	public   void CreateAccount(bankEntity bank);

	public   void ShowBalance(bankEntity bank);

	public  void Deposit(bankEntity bank);
	
	public void Withdraw(bankEntity bank);
	
	public void PrintTransactions(int id);

	public  void commitTransaction();

	public void beginTransaction();

}
